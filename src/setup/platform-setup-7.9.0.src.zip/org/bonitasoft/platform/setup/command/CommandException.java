/*  1:   */ package org.bonitasoft.platform.setup.command;
/*  2:   */ 
/*  3:   */ public class CommandException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   public CommandException(String message)
/*  7:   */   {
/*  8:23 */     super(message);
/*  9:   */   }
/* 10:   */ }


/* Location:           D:\bonita\BPM-SP-7.9.0\workspace\tomcat\setup\lib\platform-setup-7.9.0.jar
 * Qualified Name:     org.bonitasoft.platform.setup.command.CommandException
 * JD-Core Version:    0.7.0.1
 */